CREATE DATABASE araba_satis;
USE araba_satis;



-- Araclar Tablosu
CREATE TABLE araclar (
  arac_id INT auto_increment PRIMARY KEY,
  marka VARCHAR(50),
  model VARCHAR(50),
  motor_hacmi varchar(20),
  yakit_turu varchar(20),
  vites_turu varchar(10),
  fiyat DECIMAL(10, 2),
  turu varchar(20)
);

-- Musteriler Tablosu
CREATE TABLE musteriler (
  musteri_tckimlik_no BIGINT PRIMARY KEY,
  isim VARCHAR(50),
  soyisim VARCHAR(50),
  telefon_no VARCHAR(15),
  cvv CHAR(3),
  kart_numarasi VARCHAR(19),
  sk_tarihi DATE
);

-- Satislar Tablosu
CREATE TABLE teslim(
  teslim_id INT auto_increment primary KEY,
  arac_id INT,
  musteri_tckimlik_no BIGINT,
  teslimAlma_tarihi DATE,
  teslimAlinan_yer varchar(20),
  teslimEtme_tarihi date,
  teslimEdilen_yer varchar(20),
  foreign key (arac_id) references araclar(arac_id),
  foreign key (musteri_tckimlik_no) references musteriler(musteri_tckimlik_no)
);

-- Araclar Tablosuna Veri Ekleme
INSERT INTO araclar (marka, model, motor_hacmi, yakit_turu, vites_turu, fiyat, turu) VALUES
( 'Toyota', 'Corolla', '1.3', 'Benzin', 'Otomatik', 300000.00, 'Ekonomik'),
( 'Honda', 'Civic', '1.4', 'Dizel', 'Maunel' , 250000.00, 'Ekonomik' ),
( 'BMW', '3 Series', '1.5', 'Elektrikli','Otomatik',50000.00, 'Lüks'),
( 'Ford', 'Focus', '1.5', 'Benzin','Otomatik',350000.00,'Ekonomik');

-- Musteriler Tablosuna Veri Ekleme
INSERT INTO musteriler (musteri_tckimlik_no, isim, soyisim, telefon_no, cvv, kart_numarasi, sk_tarihi) VALUES
(12796873938, 'Ahmet', 'Demir', '5551234567', '365', '5647-8398-7364-5674', '2030-11-01'),
(23745859687, 'Ayşe', 'Yılmaz', '5557654321', '789', '6578-4985-6327-4635', '2025-10-01'),
(34759375849, 'Mehmet', 'Kaya', '5559876543', '128', '3746-5812-6738-3884', '2027-08-01');

-- Satislar Tablosuna Veri Ekleme
INSERT INTO teslim( arac_id, musteri_tckimlik_no ,teslimAlma_tarihi, teslimAlinan_yer, teslimEtme_tarihi, teslimEdilen_yer) VALUES
(1, 12796873938,'2023-05-15', 'İstanbul', '2023-05-25','İstanbul'),
(2, 23745859687, '2023-06-20', 'İstanbul', '2023-06-25','İstanbul' ),
(3, 34759375849, '2023-07-10', 'İstanbul', '2023-07-20', 'İstanbul' );


select*from araclar;
select*from musteriler;
select*from teslim;





