﻿namespace aracKiralama2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            textBox1 = new TextBox();
            comboBox6 = new ComboBox();
            comboBox5 = new ComboBox();
            comboBox4 = new ComboBox();
            comboBox3 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(dataGridView1);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(comboBox6);
            groupBox1.Controls.Add(comboBox5);
            groupBox1.Controls.Add(comboBox4);
            groupBox1.Controls.Add(comboBox3);
            groupBox1.Controls.Add(comboBox2);
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1044, 426);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "ARAÇ BİLGİSİ";
            // 
            // button3
            // 
            button3.BackColor = Color.Black;
            button3.FlatStyle = FlatStyle.Flat;
            button3.ForeColor = Color.OrangeRed;
            button3.Location = new Point(861, 128);
            button3.Name = "button3";
            button3.Size = new Size(150, 29);
            button3.TabIndex = 17;
            button3.Text = "VERİ GÜNCELLE";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Black;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.OrangeRed;
            button2.Location = new Point(632, 128);
            button2.Name = "button2";
            button2.Size = new Size(150, 29);
            button2.TabIndex = 16;
            button2.Text = "VERİ SİL";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.OrangeRed;
            button1.Location = new Point(394, 128);
            button1.Name = "button1";
            button1.Size = new Size(150, 29);
            button1.TabIndex = 15;
            button1.Text = "VERİ EKLE";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.DarkGray;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(394, 176);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(617, 192);
            dataGridView1.TabIndex = 14;
            dataGridView1.CellEnter += dataGridView1_CellEnter;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Black;
            textBox1.ForeColor = Color.OrangeRed;
            textBox1.Location = new Point(180, 292);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(151, 27);
            textBox1.TabIndex = 13;
            textBox1.KeyPress += textBox1_KeyPress;
            // 
            // comboBox6
            // 
            comboBox6.BackColor = Color.Black;
            comboBox6.ForeColor = Color.OrangeRed;
            comboBox6.FormattingEnabled = true;
            comboBox6.Items.AddRange(new object[] { "EKONOMİK ", "SUV", "TİCARİ", "LÜKS" });
            comboBox6.Location = new Point(180, 340);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(151, 28);
            comboBox6.TabIndex = 12;
            // 
            // comboBox5
            // 
            comboBox5.BackColor = Color.Black;
            comboBox5.ForeColor = Color.OrangeRed;
            comboBox5.FormattingEnabled = true;
            comboBox5.Items.AddRange(new object[] { "MANUEL", "OTOMATİK" });
            comboBox5.Location = new Point(180, 239);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(151, 28);
            comboBox5.TabIndex = 11;
            // 
            // comboBox4
            // 
            comboBox4.BackColor = Color.Black;
            comboBox4.ForeColor = Color.OrangeRed;
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "ELEKTİRKLİ ", "HİBRİT ", "DİZEL" });
            comboBox4.Location = new Point(180, 191);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(151, 28);
            comboBox4.TabIndex = 10;
            // 
            // comboBox3
            // 
            comboBox3.BackColor = Color.Black;
            comboBox3.ForeColor = Color.OrangeRed;
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "800cc - 1200cc", "1300cc - 1600cc", "1800cc - 2000cc", "2000cc - 3000cc", "3000cc+" });
            comboBox3.Location = new Point(180, 149);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(151, 28);
            comboBox3.TabIndex = 9;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.Black;
            comboBox2.ForeColor = Color.OrangeRed;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "AUDİ A3", "BMW 3.16", "CİTROEN C3", "DACİA DUSTER", "DACİA LOGAN", "DACİA SANDERO", "FİAT EGEA SEDAN", "FİAT EGEA CROSS", "HYUNDAİ BAYON", "HYUNDAİ İ20", "HYUNDAİ TUCSON ", "KİA PİCANTO ", "PEUGEOT 308", "PEUGEOT 2008", "RENAULT CLİO", "RENAULT MEGANE SEDAN", "RENAULT CAPTUR", "VOLKSWAGEN PASSAT", "TOYOTA YARİS", "NİSSAN QASHQAİ" });
            comboBox2.Location = new Point(180, 98);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(151, 28);
            comboBox2.TabIndex = 8;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.Black;
            comboBox1.ForeColor = Color.OrangeRed;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "AUDİ", "BMW ", "CİTROEN", "DACİA", "FİAT ", "HYUNDAİ", "KİA ", "PEUGEOT ", "RENAULT ", "VOLKSWAGEN ", "TOYOTA ", "NİSSAN " });
            comboBox1.Location = new Point(180, 49);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 7;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = Color.OrangeRed;
            label7.Location = new Point(29, 348);
            label7.Name = "label7";
            label7.Size = new Size(53, 20);
            label7.TabIndex = 6;
            label7.Text = "TÜRÜ :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.OrangeRed;
            label6.Location = new Point(29, 299);
            label6.Name = "label6";
            label6.Size = new Size(51, 20);
            label6.TabIndex = 5;
            label6.Text = "FİYAT :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.OrangeRed;
            label5.Location = new Point(29, 247);
            label5.Name = "label5";
            label5.Size = new Size(94, 20);
            label5.TabIndex = 4;
            label5.Text = "VİTES TÜRÜ :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.OrangeRed;
            label4.Location = new Point(29, 199);
            label4.Name = "label4";
            label4.Size = new Size(95, 20);
            label4.TabIndex = 3;
            label4.Text = "YAKIT TÜRÜ :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.OrangeRed;
            label3.Location = new Point(29, 152);
            label3.Name = "label3";
            label3.Size = new Size(117, 20);
            label3.TabIndex = 2;
            label3.Text = "MOTOR HACMİ :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.OrangeRed;
            label2.Location = new Point(29, 106);
            label2.Name = "label2";
            label2.Size = new Size(66, 20);
            label2.TabIndex = 1;
            label2.Text = "MODEL :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.OrangeRed;
            label1.Location = new Point(29, 52);
            label1.Name = "label1";
            label1.Size = new Size(67, 20);
            label1.TabIndex = 0;
            label1.Text = "MARKA :";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1068, 467);
            Controls.Add(groupBox1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox1;
        private ComboBox comboBox6;
        private ComboBox comboBox5;
        private ComboBox comboBox4;
        private ComboBox comboBox3;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button3;
        private Button button2;
        private Button button1;
        private DataGridView dataGridView1;
    }
}