namespace aracKiralama2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 arabaForm = new Form2();
            arabaForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 musteriForm = new Form3();
            musteriForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 teslimForm = new Form4();
            teslimForm.Show();
        }
    }
}
