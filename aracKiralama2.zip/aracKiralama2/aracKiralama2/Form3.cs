﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// using MySqlConnector;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
// using Mysqlx.Connection

namespace aracKiralama2
{

    public partial class Form3 : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=araba_satis;UID=root;Password=Elifsude123;");
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable dt;

        void musteriler()
        {
            dt = new DataTable();
            connection.Open();
            adapter = new MySqlDataAdapter("SELECT * FROM musteriler", connection);
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
            connection.Close();
        }
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            musteriler();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!maskedTextBox3.MaskFull)
            {
                MessageBox.Show("CVV 3 haneli bir sayı olmalıdır!");
                return;
            }


            string tckimlik = maskedTextBox1.Text.Trim();
            string isim = textBox1.Text.Trim();
            string soyisim = textBox2.Text.Trim();
            string telefon = maskedTextBox2.Text.Trim();
            string kartNo = maskedTextBox4.Text.Replace("-", "").Trim();
            string skTarihiText = maskedTextBox5.Text.Trim();

            DateTime skTarihi;
            if (!DateTime.TryParse(skTarihiText, out skTarihi))
            {
                MessageBox.Show("Son kullanma tarihi geçerli bir tarih değil!");
                return;
            }

            // Komut
            string sql = "INSERT INTO musteriler (musteri_tckimlik_no, isim, soyisim, telefon_no, cvv, kart_numarasi, sk_tarihi) " +
                         "VALUES (@musteri_tckimlik_no, @isim, @soyisim, @telefon_no, @cvv, @kart_numarasi, @sk_tarihi)";

            command = new MySqlCommand(sql, connection);

            // Parametreler
            command.Parameters.AddWithValue("@musteri_tckimlik_no", Convert.ToInt64(tckimlik));
            command.Parameters.AddWithValue("@isim", isim);
            command.Parameters.AddWithValue("@soyisim", soyisim);
            command.Parameters.AddWithValue("@telefon_no", telefon);
            command.Parameters.AddWithValue("@cvv", maskedTextBox3.Text.Trim());  // Direkt olarak 'cvv' ekleniyor
            command.Parameters.AddWithValue("@kart_numarasi", kartNo);
            command.Parameters.AddWithValue("@sk_tarihi", skTarihi.ToString("yyyy-MM-dd"));

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Müşteri başarıyla eklendi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                connection.Close();
                musteriler();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            // Seçili satırdan TC Kimlik numarasını alıyoruz
            string tckimlik = maskedTextBox1.Text.Trim();

            if (string.IsNullOrEmpty(tckimlik))
            {
                MessageBox.Show("Lütfen silinecek müşteri bilgisini seçin.");
                return;
            }

            // SQL DELETE sorgusu
            string sql = "DELETE FROM musteriler WHERE musteri_tckimlik_no = @musteri_tckimlik_no";

            try
            {
                // Bağlantıyı açıyoruz
                connection.Open();

                // Komut nesnesini oluşturuyoruz
                command = new MySqlCommand(sql, connection);

                // Parametre ekliyoruz
                command.Parameters.AddWithValue("@musteri_tckimlik_no", Convert.ToInt64(tckimlik));

                // Sorguyu çalıştırıyoruz
                int result = command.ExecuteNonQuery();

                // Eğer bir satır silindiyse, kullanıcıya başarılı mesajı veriyoruz
                if (result > 0)
                {
                    MessageBox.Show("Müşteri başarıyla silindi.");
                }
                else
                {
                    MessageBox.Show("Silinecek müşteri bulunamadı.");
                }
            }
            catch (Exception ex)
            {
                // Hata mesajını gösteriyoruz
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapatıyoruz
                connection.Close();

                // Veri tablosunu güncelliyoruz
                musteriler();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Seçili satırdan TC Kimlik numarasını alıyoruz
            string tckimlik = maskedTextBox1.Text.Trim();

            if (string.IsNullOrEmpty(tckimlik))
            {
                MessageBox.Show("Lütfen güncellenecek müşteri bilgisini seçin.");
                return;
            }

            string isim = textBox1.Text.Trim();
            string soyisim = textBox2.Text.Trim();
            string telefon = maskedTextBox2.Text.Trim();
            string kartNo = maskedTextBox4.Text.Replace(" ", "").Trim();
            string cvv = maskedTextBox3.Text.Trim();
            string skTarihiText = maskedTextBox5.Text.Trim();

            // Tarih formatı kontrolü
            DateTime skTarihi;
            if (!DateTime.TryParse(skTarihiText, out skTarihi))
            {
                MessageBox.Show("Son kullanma tarihi geçerli bir tarih değil!");
                return;
            }

            // SQL UPDATE sorgusu
            string sql = "UPDATE musteriler SET isim = @isim, soyisim = @soyisim, telefon_no = @telefon_no, " +
                         "cvv = @cvv, kart_numarasi = @kart_numarasi, sk_tarihi = @sk_tarihi " +
                         "WHERE musteri_tckimlik_no = @musteri_tckimlik_no";

            try
            {
                // Bağlantıyı açıyoruz
                connection.Open();

                // Komut nesnesini oluşturuyoruz
                command = new MySqlCommand(sql, connection);

                // Parametreler
                command.Parameters.AddWithValue("@musteri_tckimlik_no", Convert.ToInt64(tckimlik));
                command.Parameters.AddWithValue("@isim", isim);
                command.Parameters.AddWithValue("@soyisim", soyisim);
                command.Parameters.AddWithValue("@telefon_no", telefon);
                command.Parameters.AddWithValue("@cvv", cvv);
                command.Parameters.AddWithValue("@kart_numarasi", kartNo);
                command.Parameters.AddWithValue("@sk_tarihi", skTarihi);

                // Sorguyu çalıştırıyoruz
                int result = command.ExecuteNonQuery();

                // Eğer bir satır güncellenmişse, kullanıcıya başarılı mesajı veriyoruz
                if (result > 0)
                {
                    MessageBox.Show("Müşteri bilgileri başarıyla güncellendi.");
                }
                else
                {
                    MessageBox.Show("Güncellenmek istenen müşteri bulunamadı.");
                }
            }
            catch (Exception ex)
            {
                // Hata mesajını gösteriyoruz
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapatıyoruz
                connection.Close();

                // Veri tablosunu güncelliyoruz
                musteriler();
            }
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                maskedTextBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                maskedTextBox2.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                maskedTextBox3.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                maskedTextBox4.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                maskedTextBox5.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            }
            catch
            {
                throw;
            }
        }

        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
