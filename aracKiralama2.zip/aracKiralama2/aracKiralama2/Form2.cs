﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// using MySqlConnector;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
// using Mysqlx.Connection

namespace aracKiralama2
{
    public partial class Form2 : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=araba_satis;UID=root;Password=Elifsude123;");
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable dt;

        void araclar()
        {
            dt = new DataTable();
            connection.Open();
            adapter = new MySqlDataAdapter("SELECT * FROM araclar", connection);
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
            connection.Close();
        }


        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Sayı değilse ve backspace değilse girişe izin verme
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            araclar();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO araclar (marka, model, motor_hacmi, yakit_turu, vites_turu, fiyat, turu) " +
                 "VALUES (@marka, @model, @motor_hacmi, @yakit_turu, @vites_turu, @fiyat, @turu)";

            command = new MySqlCommand(sql, connection);

            command.Parameters.AddWithValue("@marka", comboBox1.Text);
            command.Parameters.AddWithValue("@model", comboBox2.Text);
            command.Parameters.AddWithValue("@motor_hacmi", comboBox3.Text);
            command.Parameters.AddWithValue("@yakit_turu", comboBox4.Text);
            command.Parameters.AddWithValue("@vites_turu", comboBox5.Text);
            command.Parameters.AddWithValue("@fiyat", Convert.ToDecimal(textBox1.Text));
            command.Parameters.AddWithValue("@turu", comboBox6.Text);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Araç başarıyla eklendi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                connection.Close();
                araclar();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int selectedRowId = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            string sql = "DELETE FROM araclar WHERE arac_id = @id";
            command = new MySqlCommand(sql, connection);
            command.Parameters.AddWithValue("@id", selectedRowId);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Araç başarıyla silindi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                connection.Close();
                araclar();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int selectedRowId = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            string sql = "UPDATE araclar SET marka = @marka, model = @model, motor_hacmi = @motor_hacmi, " +
                         "yakit_turu = @yakit_turu, vites_turu = @vites_turu, fiyat = @fiyat, turu = @turu WHERE arac_id = @id";

            command = new MySqlCommand(sql, connection);

            command.Parameters.AddWithValue("@id", selectedRowId);
            command.Parameters.AddWithValue("@marka", comboBox1.Text);
            command.Parameters.AddWithValue("@model", comboBox2.Text);
            command.Parameters.AddWithValue("@motor_hacmi", comboBox3.Text);
            command.Parameters.AddWithValue("@yakit_turu", comboBox4.Text);
            command.Parameters.AddWithValue("@vites_turu", comboBox5.Text);
            command.Parameters.AddWithValue("@fiyat", Convert.ToDecimal(textBox1.Text));
            command.Parameters.AddWithValue("@turu", comboBox5.Text);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Araç bilgileri güncellendi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                connection.Close();
                araclar();
            }
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            comboBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            comboBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            comboBox3.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            comboBox4.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            comboBox5.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            comboBox6.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
        }
    }

}
    

