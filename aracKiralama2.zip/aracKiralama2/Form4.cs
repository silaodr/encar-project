﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// using MySqlConnector;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
// using Mysqlx.Connection


namespace aracKiralama2
{
    public partial class Form4 : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=araba_satis;UID=root;Password=Elifsude123;");
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable dt;

        void teslim()
        {
            dt = new DataTable();
            connection.Open();
            adapter = new MySqlDataAdapter("SELECT * FROM teslim", connection);
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
            connection.Close();
        }
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            teslim();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            connection.Open();
            MySqlCommand command = new MySqlCommand("INSERT INTO teslim (teslimAlma_tarihi, teslimAlinan_yer, teslimEtme_tarihi, teslimEdilen_yer) VALUES (@teslimAlma_tarihi, @teslimAlinan_yer, @teslimEtme_tarihi, @teslimEdilen_yer)", connection);


            command.Parameters.AddWithValue("@teslimAlma_tarihi", dateTimePicker1.Value.Date);
            command.Parameters.AddWithValue("@teslimAlinan_yer", comboBox1.Text);
            command.Parameters.AddWithValue("@teslimEtme_tarihi", dateTimePicker2.Value.Date);
            command.Parameters.AddWithValue("@teslimEdilen_yer", comboBox2.Text);


            command.ExecuteNonQuery();
            connection.Close();


            MessageBox.Show("Veri Eklendi!");
            teslim();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int teslimId;
                if (int.TryParse(dataGridView1.CurrentRow.Cells[0].Value.ToString(), out teslimId))
                {
                    try
                    {
                        connection.Open(); 
                        MySqlCommand command = new MySqlCommand("DELETE FROM teslim WHERE teslim_id = @id", connection);
                        command.Parameters.AddWithValue("@id", teslimId);
                        command.ExecuteNonQuery();
                        connection.Close();
                        MessageBox.Show("Kayıt Silindi!");
                        teslim();
                    }
                    catch (MySqlException ex)
                    {
                        
                        MessageBox.Show("Silme işlemi sırasında bir hata oluştu: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Geçersiz teslim ID.");
                }
            }
            else
            {
                MessageBox.Show("Lütfen bir kayıt seçin!");
            }
        }
    }
}
